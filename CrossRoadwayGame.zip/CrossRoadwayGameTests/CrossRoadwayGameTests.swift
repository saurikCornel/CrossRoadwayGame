//
//  CrossRoadwayGameTests.swift
//  CrossRoadwayGameTests
//
//  Created by alex on 3/19/25.
//

import Testing
@testable import CrossRoadwayGame

struct CrossRoadwayGameTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
