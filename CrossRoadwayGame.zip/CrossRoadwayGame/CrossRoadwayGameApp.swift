//
//  CrossRoadwayGameApp.swift
//  CrossRoadwayGame
//
//  Created by alex on 3/19/25.
//

import SwiftUI

@main
struct CrossRoadwayGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
